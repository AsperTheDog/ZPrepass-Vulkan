#pragma once
#include <vulkan/vulkan_core.h>

#include "vulkan_memory.hpp"

class VulkanDevice;

class VulkanBuffer
{
public:

	[[nodiscard]] VkMemoryRequirements getMemoryRequirements() const;
	
	void allocateFromIndex(uint32_t memoryIndex);
	void allocateFromFlags(const VulkanMemoryAllocator::MemoryPropertyPreferences memoryProperties);

	[[nodiscard]] bool isMemoryMapped() const;
	[[nodiscard]] void* getMappedData() const;
	void* map(VkDeviceSize size, VkDeviceSize offset);
	void unmap();

private:
	VulkanBuffer() = default;
	VulkanBuffer(VulkanDevice& device, VkBuffer vkHandle);
	void setBoundMemory(const MemoryChunk::MemoryBlock& memoryRegion);
	void free();

	MemoryChunk::MemoryBlock m_memoryRegion;
	VulkanDevice* m_device = nullptr;

	VkBuffer m_vkHandle = VK_NULL_HANDLE;

	void* m_mappedData = nullptr;

	friend class VulkanDevice;
};

