#pragma once
#include <SDL2/SDL_vulkan.h>
#include <string_view>
#include <vector>
#include <vulkan/vulkan_core.h>

class VulkanDevice;
class VulkanContext;

class SDLWindow
{
public:
	struct WindowSize
	{
		uint32_t width;
		uint32_t height;
	};

	SDLWindow(std::string_view name, int width, int height, int top = SDL_WINDOWPOS_CENTERED, int left = SDL_WINDOWPOS_CENTERED, uint32_t flags = SDL_WINDOW_SHOWN | SDL_WINDOW_MAXIMIZED);

	[[nodiscard]] bool shouldClose() const;
	[[nodiscard]] std::vector<const char*> getRequiredVulkanExtensions() const;
	[[nodiscard]] WindowSize getSize() const;

	void pollEvents() const;

	void createSurface(const VulkanContext& instance);
	void createSwapchain(const VulkanDevice& device, const VkSurfaceFormatKHR desiredFormat);

	SDL_Window* operator*() const;
	[[nodiscard]] VkSurfaceKHR getSurface() const;

	void free();

private:
	struct Swapchain
	{
		VkSwapchainKHR swapchain = nullptr;
		VkExtent2D extent;
		VkSurfaceFormatKHR format;
		std::vector<VkImage> images;
		std::vector<VkImageView> imageViews;
	};

	SDL_Window* m_SDLHandle = nullptr;
	VkSurfaceKHR m_surface = nullptr;
	Swapchain m_swapchain{};

	VkDevice m_device = nullptr;
	VkInstance m_instance = nullptr;

	friend class Surface;
	friend class VulkanGPU;
};

