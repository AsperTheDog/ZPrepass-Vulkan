#pragma once
#include <map>
#include <vulkan/vulkan_core.h>

#include "vulkan_buffer.hpp"
#include "Vulkan_gpu.hpp"
#include "vulkan_queues.hpp"

class VulkanQueue;

class VulkanDevice
{
public:
 	
	void initializeCommandPool(const QueueFamily& family, uint32_t threadID, bool secondary, bool isProtected);
	std::vector<VkCommandBuffer> createCommandBuffers(const QueueFamily& family, uint32_t threadID, uint32_t count, bool isSecondary);
	VkCommandBuffer createSingleCommandBuffer(const QueueFamily& family, uint32_t threadID, bool isSecondary);
	VkCommandBuffer getOrCreateSingleCommandBuffer(const QueueFamily& family, uint32_t threadID, bool isSecondary);

	VulkanBuffer createBuffer(VkDeviceSize size, VkBufferUsageFlags usage, bool allocateMemory);
	void configureStagingBuffer(VkDeviceSize size, const QueueSelection& queue, bool forceAllowStagingMemory = false);

	void disallowMemoryType(uint32_t type);
	void allowMemoryType(uint32_t type);

	void free();

	[[nodiscard]] VulkanQueue getQueue(const QueueSelection& queueSelection) const;
	[[nodiscard]] VulkanGPU getGPU() const;
	[[nodiscard]] const VulkanMemoryAllocator& getMemoryAllocator() const;

private:
	[[nodiscard]] VkDeviceMemory getMemoryHandle(uint32_t chunk) const;

	struct ThreadCommandInfo
	{
		struct CommandPoolInfo
		{
			VkCommandPool pool = VK_NULL_HANDLE;
			VkCommandPool secondaryPool = VK_NULL_HANDLE;

			std::vector<VkCommandBuffer> commandBuffers;
			std::vector<VkCommandBuffer> secondaryCommandBuffers;
		};

		std::map<uint32_t, CommandPoolInfo> commandPools;
	};

	struct StagingBufferInfo
	{
		VulkanBuffer stagingBuffer{};
		QueueSelection queue{};
	} m_stagingBufferInfo;

	VulkanDevice() = default;
	VulkanDevice(VulkanGPU pDevice, VkDevice device);

	VkDevice m_vkHandle;

	VulkanGPU m_physicalDevice;

	std::map<uint32_t, ThreadCommandInfo> m_threadCommandInfos;
	std::vector<VkBuffer> m_buffers;

	VulkanMemoryAllocator m_memoryAllocator;

	friend class VulkanContext;
	friend class SDLWindow;
	friend class VulkanGPU;
	friend class VulkanResource;
	friend class VulkanMemoryAllocator;
	friend class VulkanBuffer;
};
