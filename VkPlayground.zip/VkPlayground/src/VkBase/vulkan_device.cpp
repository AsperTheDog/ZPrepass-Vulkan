#include "vulkan_device.hpp"

#include <ranges>
#include <stdexcept>

#include "vulkan_buffer.hpp"
#include "vulkan_queues.hpp"

VulkanQueue VulkanDevice::getQueue(const QueueSelection& queueSelection) const
{
	VulkanQueue queue;
	vkGetDeviceQueue(m_vkHandle, queueSelection.familyIndex, queueSelection.queueIndex, &queue.m_vkHandle);
	return queue;
}

VulkanGPU VulkanDevice::getGPU() const
{
	return m_physicalDevice;
}

const VulkanMemoryAllocator& VulkanDevice::getMemoryAllocator() const
{
	return m_memoryAllocator;
}

void VulkanDevice::initializeCommandPool(const QueueFamily& family, const uint32_t threadID, const bool createSecondary, const bool isProtected)
{
	if (!m_threadCommandInfos.contains(threadID))
	{
		m_threadCommandInfos[threadID] = {};
	}

	ThreadCommandInfo& threadInfo = m_threadCommandInfos[threadID];
	if (!threadInfo.commandPools.contains(family.index))
	{
		VkCommandPoolCreateInfo poolInfo{};
		poolInfo.sType = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO;
		poolInfo.queueFamilyIndex = family.index;
		poolInfo.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
		if (isProtected)
		{
			poolInfo.flags |= VK_COMMAND_POOL_CREATE_PROTECTED_BIT;
		}

		VkCommandPool pool;
		if (vkCreateCommandPool(m_vkHandle, &poolInfo, nullptr, &threadInfo.commandPools[family.index].pool) != VK_SUCCESS)
		{
			throw std::runtime_error("Failed to create command pool");
		}

		if (createSecondary)
		{
			if (vkCreateCommandPool(m_vkHandle, &poolInfo, nullptr, &threadInfo.commandPools[family.index].secondaryPool) != VK_SUCCESS)
			{
				throw std::runtime_error("Failed to create secondary command pool");
			}
		}
	}
}

std::vector<VkCommandBuffer> VulkanDevice::createCommandBuffers(const QueueFamily& family, const uint32_t threadID, const uint32_t count, const bool isSecondary)
{
	initializeCommandPool(family, threadID, false, isSecondary);

	VkCommandBufferAllocateInfo allocInfo{};
	allocInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
	if (isSecondary)
	{
		allocInfo.level = VK_COMMAND_BUFFER_LEVEL_SECONDARY;
		allocInfo.commandPool = m_threadCommandInfos[threadID].commandPools[family.index].secondaryPool;
	}
	else
	{
		allocInfo.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
		allocInfo.commandPool = m_threadCommandInfos[threadID].commandPools[family.index].pool;
	}
	allocInfo.commandBufferCount = count;

	std::vector<VkCommandBuffer> commandBuffers(count);
	if (vkAllocateCommandBuffers(m_vkHandle, &allocInfo, commandBuffers.data()) != VK_SUCCESS)
	{
		throw std::runtime_error("Failed to allocate command buffers");
	}

	for (const auto& commandBuffer : commandBuffers)
	{
		if (isSecondary) 
			m_threadCommandInfos[threadID].commandPools[family.index].secondaryCommandBuffers.push_back(commandBuffer);
		else 
			m_threadCommandInfos[threadID].commandPools[family.index].commandBuffers.push_back(commandBuffer);
	}

	return commandBuffers;
}

VkCommandBuffer VulkanDevice::createSingleCommandBuffer(const QueueFamily& family, const uint32_t threadID, const bool isSecondary)
{
	initializeCommandPool(family, threadID, false, isSecondary);

	VkCommandBufferAllocateInfo allocInfo{};
	allocInfo.sType = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO;
	if (isSecondary)
	{
		allocInfo.level = VK_COMMAND_BUFFER_LEVEL_SECONDARY;
		allocInfo.commandPool = m_threadCommandInfos[threadID].commandPools[family.index].secondaryPool;
	}
	else
	{
		allocInfo.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
		allocInfo.commandPool = m_threadCommandInfos[threadID].commandPools[family.index].pool;
	}
	allocInfo.commandBufferCount = 1;

	VkCommandBuffer commandBuffer;
	if (vkAllocateCommandBuffers(m_vkHandle, &allocInfo, &commandBuffer) != VK_SUCCESS)
	{
		throw std::runtime_error("Failed to allocate command buffer");
	}

	if (isSecondary) 
		m_threadCommandInfos[threadID].commandPools[family.index].secondaryCommandBuffers.push_back(commandBuffer);
	else 
		m_threadCommandInfos[threadID].commandPools[family.index].commandBuffers.push_back(commandBuffer);

	return commandBuffer;
}

VkCommandBuffer VulkanDevice::getOrCreateSingleCommandBuffer(const QueueFamily& family, const uint32_t threadID, const bool isSecondary)
{
	if (isSecondary && !m_threadCommandInfos[threadID].commandPools[family.index].secondaryCommandBuffers.empty())
	{
		return m_threadCommandInfos[threadID].commandPools[family.index].secondaryCommandBuffers[0];
	}

	if (!isSecondary && !m_threadCommandInfos[threadID].commandPools[family.index].commandBuffers.empty())
	{
		return m_threadCommandInfos[threadID].commandPools[family.index].commandBuffers[0];
	}

	return createSingleCommandBuffer(family, threadID, isSecondary);
	
}

VulkanBuffer VulkanDevice::createBuffer(const VkDeviceSize size, const VkBufferUsageFlags usage, bool allocateMemory)
{
	VkBufferCreateInfo bufferInfo{};
	bufferInfo.sType = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO;
	bufferInfo.size = size;
	bufferInfo.usage = usage;
	bufferInfo.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
	bufferInfo.flags = 0;

	VkBuffer buffer;
	if (vkCreateBuffer(m_vkHandle, &bufferInfo, nullptr, &buffer) != VK_SUCCESS)
	{
		throw std::runtime_error("Failed to create buffer");
	}
	m_buffers.push_back(buffer);

	return {*this, buffer};
}

void VulkanDevice::configureStagingBuffer(const VkDeviceSize size, const QueueSelection& queue, const bool forceAllowStagingMemory)
{
	if (m_stagingBufferInfo.stagingBuffer.m_vkHandle != VK_NULL_HANDLE)
	{
		throw std::runtime_error("Staging buffer already configured! Reconfiguration is not implemented yet TvT");
	}

	m_stagingBufferInfo.stagingBuffer = createBuffer(size, VK_BUFFER_USAGE_TRANSFER_SRC_BIT, false);

	m_stagingBufferInfo.queue = queue;

	const VkMemoryRequirements memRequirements = m_stagingBufferInfo.stagingBuffer.getMemoryRequirements();
	const std::optional<uint32_t> memoryType = m_memoryAllocator.getMemoryStructure().getStagingMemoryType(memRequirements.memoryTypeBits);
	if (memoryType.has_value() && !m_memoryAllocator.isMemoryTypeHidden(memoryType.value()))
	{
		m_stagingBufferInfo.stagingBuffer.allocateFromIndex(memoryType.value());
		if (!forceAllowStagingMemory)
			m_memoryAllocator.hideMemoryType(memoryType.value());
	}
	else
	{
		m_stagingBufferInfo.stagingBuffer.allocateFromFlags({VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, VK_MEMORY_PROPERTY_HOST_CACHED_BIT, true});
	}
}

void VulkanDevice::disallowMemoryType(const uint32_t type)
{
	m_memoryAllocator.hideMemoryType(type);
}

void VulkanDevice::allowMemoryType(const uint32_t type)
{
	m_memoryAllocator.unhideMemoryType(type);
}

void VulkanDevice::free()
{
	for (const auto& threadInfo : m_threadCommandInfos | std::views::values)
	{
		for (const auto& commandPoolInfo : threadInfo.commandPools | std::views::values)
		{
			if (commandPoolInfo.pool != VK_NULL_HANDLE)
			{
				for (const auto& commandBuffer : commandPoolInfo.commandBuffers)
					vkFreeCommandBuffers(m_vkHandle, commandPoolInfo.pool, 1, &commandBuffer);

				vkDestroyCommandPool(m_vkHandle, commandPoolInfo.pool, nullptr);
			}
			if (commandPoolInfo.secondaryPool != VK_NULL_HANDLE)
			{
				for (const auto& commandBuffer : commandPoolInfo.secondaryCommandBuffers)
					vkFreeCommandBuffers(m_vkHandle, commandPoolInfo.secondaryPool, 1, &commandBuffer);

				vkDestroyCommandPool(m_vkHandle, commandPoolInfo.secondaryPool, nullptr);
			}
		}
	}

	m_threadCommandInfos.clear();

	if (m_stagingBufferInfo.stagingBuffer.m_vkHandle != VK_NULL_HANDLE)
	{
		m_stagingBufferInfo.stagingBuffer.free();
	}

	m_memoryAllocator.free();

	vkDestroyDevice(m_vkHandle, nullptr);
}

VkDeviceMemory VulkanDevice::getMemoryHandle(const uint32_t chunk) const
{
	return m_memoryAllocator.m_memoryChunks[chunk].m_memory;
}

VulkanDevice::VulkanDevice(const VulkanGPU pDevice, const VkDevice device)
	: m_vkHandle(device), m_physicalDevice(pDevice), m_memoryAllocator(*this)
{

}
