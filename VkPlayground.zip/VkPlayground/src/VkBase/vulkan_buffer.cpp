#include "vulkan_buffer.hpp"

#include <stdexcept>

#include "vulkan_device.hpp"

VkMemoryRequirements VulkanBuffer::getMemoryRequirements() const
{
	VkMemoryRequirements memoryRequirements;
	vkGetBufferMemoryRequirements(m_device->m_vkHandle, m_vkHandle, &memoryRequirements);
	return memoryRequirements;
}

void VulkanBuffer::allocateFromIndex(const uint32_t memoryIndex)
{
	setBoundMemory(m_device->m_memoryAllocator.allocate(getMemoryRequirements().size, memoryIndex));
}

void VulkanBuffer::allocateFromFlags(const VulkanMemoryAllocator::MemoryPropertyPreferences memoryProperties)
{
	setBoundMemory(m_device->m_memoryAllocator.searchAndAllocate(getMemoryRequirements().size, memoryProperties, getMemoryRequirements().memoryTypeBits));
}

bool VulkanBuffer::isMemoryMapped() const
{
	return m_mappedData != nullptr;
}

void* VulkanBuffer::getMappedData() const
{
	return m_mappedData;
}

void* VulkanBuffer::map(const VkDeviceSize size, const VkDeviceSize offset)
{
	void* data;
	vkMapMemory(m_device->m_vkHandle, m_device->getMemoryHandle(m_memoryRegion.chunk), m_memoryRegion.offset + offset, size, 0, &data);
	m_mappedData = data;
	return data;
}

void VulkanBuffer::unmap()
{
	vkUnmapMemory(m_device->m_vkHandle, m_device->getMemoryHandle(m_memoryRegion.chunk));
	m_mappedData = nullptr;
}

VulkanBuffer::VulkanBuffer(VulkanDevice& device, const VkBuffer vkHandle)
	: m_device(&device), m_vkHandle(vkHandle)
{
	
}

void VulkanBuffer::setBoundMemory(const MemoryChunk::MemoryBlock& memoryRegion)
{
	if (m_memoryRegion.size > 0)
	{
		throw std::runtime_error("Buffer already has memory bound to it!");
	}
	m_memoryRegion = memoryRegion;

	vkBindBufferMemory(m_device->m_vkHandle, m_vkHandle, m_device->getMemoryHandle(m_memoryRegion.chunk), m_memoryRegion.offset);
}

void VulkanBuffer::free()
{
	vkDestroyBuffer(m_device->m_vkHandle, m_vkHandle, nullptr);
	m_vkHandle = VK_NULL_HANDLE;

	if (m_memoryRegion.size > 0)
	{
		m_device->m_memoryAllocator.deallocate(m_memoryRegion);
		m_memoryRegion = {};
	} 
}
