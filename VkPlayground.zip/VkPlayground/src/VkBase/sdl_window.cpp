#include "sdl_window.hpp"

#include <stdexcept>
#include <SDL2/SDL.h>

#include "vulkan_context.hpp"
#include "vulkan_device.hpp"

SDLWindow::SDLWindow(const std::string_view name, const int width, const int height, const int top, const int left, const uint32_t flags)
{
	SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS);
	m_SDLHandle = SDL_CreateWindow(name.data(), top, left, width, height, flags | SDL_WINDOW_VULKAN);
}

bool SDLWindow::shouldClose() const
{
	return SDL_QuitRequested();
}

std::vector<const char*> SDLWindow::getRequiredVulkanExtensions() const
{
	uint32_t extensionCount;
	SDL_Vulkan_GetInstanceExtensions(m_SDLHandle, &extensionCount, nullptr);

	std::vector<const char*> extensions(extensionCount);
	SDL_Vulkan_GetInstanceExtensions(m_SDLHandle, &extensionCount, extensions.data());

	return extensions;
}

SDLWindow::WindowSize SDLWindow::getSize() const
{
	int width, height;
	SDL_GetWindowSize(m_SDLHandle, &width, &height);
	return {static_cast<uint32_t>(width), static_cast<uint32_t>(height)};
}

void SDLWindow::pollEvents() const
{
	SDL_Event event;
	while (SDL_PollEvent(&event))
	{

	}
}

void SDLWindow::createSurface(const VulkanContext& instance)
{
	if (m_surface != nullptr) 
		throw std::runtime_error("Surface already created");

	if (SDL_Vulkan_CreateSurface(m_SDLHandle, instance.m_vkHandle, &m_surface) == SDL_FALSE)
		throw std::runtime_error("failed to create SDLHandle surface!");

	m_instance = instance.m_vkHandle;
}

void SDLWindow::createSwapchain(const VulkanDevice& device, const VkSurfaceFormatKHR desiredFormat)
{
	const VkSurfaceCapabilitiesKHR capabilities = device.m_physicalDevice.getCapabilities(*this);

	VkSwapchainCreateInfoKHR createInfo{};
	createInfo.sType = VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR;
	createInfo.surface = m_surface;
	createInfo.minImageCount = capabilities.minImageCount + 1;
    if (capabilities.maxImageCount > 0 && createInfo.minImageCount > capabilities.maxImageCount)
        createInfo.minImageCount = capabilities.maxImageCount;
	const VkSurfaceFormatKHR selectedFormat = device.getGPU().getClosestFormat(*this, desiredFormat);
	createInfo.imageFormat = selectedFormat.format;
	createInfo.imageColorSpace = selectedFormat.colorSpace;
	if (capabilities.currentExtent.width != UINT32_MAX)
	{
		createInfo.imageExtent = capabilities.currentExtent;
	}
	else
	{
		createInfo.imageExtent.width = getSize().width;
		createInfo.imageExtent.height = getSize().height;
	}
	createInfo.imageArrayLayers = 1;
	createInfo.imageUsage = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT;
	createInfo.imageSharingMode = VK_SHARING_MODE_EXCLUSIVE;
	createInfo.preTransform = capabilities.currentTransform;
	createInfo.compositeAlpha = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;
	createInfo.presentMode = VK_PRESENT_MODE_FIFO_KHR;
	createInfo.clipped = VK_TRUE;

	if (vkCreateSwapchainKHR(device.m_vkHandle, &createInfo, nullptr, &m_swapchain.swapchain) != VK_SUCCESS)
		throw std::runtime_error("failed to create swap chain!");

	m_swapchain.format = selectedFormat;
	m_swapchain.extent = createInfo.imageExtent;

	// Get iamges
	uint32_t imageCount;
	vkGetSwapchainImagesKHR(device.m_vkHandle, m_swapchain.swapchain, &imageCount, nullptr);
    m_swapchain.images.resize(imageCount);
    vkGetSwapchainImagesKHR(device.m_vkHandle, m_swapchain.swapchain, &imageCount, m_swapchain.images.data());

	// Create image views
	m_swapchain.imageViews.resize(m_swapchain.images.size());
    for (uint32_t i = 0; i < m_swapchain.images.size(); i++) {
		VkImageViewCreateInfo viewInfo{};
        viewInfo.sType = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO;
        viewInfo.image = m_swapchain.images[i];
        viewInfo.viewType = VK_IMAGE_VIEW_TYPE_2D;
        viewInfo.format = selectedFormat.format;
        viewInfo.subresourceRange.aspectMask = VK_IMAGE_ASPECT_COLOR_BIT;
        viewInfo.subresourceRange.baseMipLevel = 0;
        viewInfo.subresourceRange.levelCount = 1;
        viewInfo.subresourceRange.baseArrayLayer = 0;
        viewInfo.subresourceRange.layerCount = 1;

        if (vkCreateImageView(device.m_vkHandle, &viewInfo, nullptr, &m_swapchain.imageViews[i]) != VK_SUCCESS) {
            throw std::runtime_error("failed to create texture image view!");
        }
    }

	m_device = device.m_vkHandle;
}

SDL_Window* SDLWindow::operator*() const
{
	return m_SDLHandle;
}

VkSurfaceKHR SDLWindow::getSurface() const
{
	return m_surface;
}

void SDLWindow::free()
{
	if (m_swapchain.swapchain != nullptr && m_device != nullptr)
	{
		for (const auto& imageView : m_swapchain.imageViews)
		{
			vkDestroyImageView(m_device, imageView, nullptr);
		}
		vkDestroySwapchainKHR(m_device, m_swapchain.swapchain, nullptr);
		m_swapchain = {};
	}

	if (m_surface != nullptr && m_instance != nullptr)
	{
		vkDestroySurfaceKHR(m_instance, m_surface, nullptr);
		m_surface = nullptr;
	}

	SDL_DestroyWindow(m_SDLHandle);
	SDL_Quit();
	m_SDLHandle = nullptr;
}
