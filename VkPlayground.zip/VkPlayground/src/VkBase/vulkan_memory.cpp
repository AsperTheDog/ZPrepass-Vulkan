#include "vulkan_memory.hpp"

#include <iostream>
#include <ranges>
#include <stdexcept>
#include <vulkan/vk_enum_string_helper.h>
#include <vulkan/vulkan_core.h>

#include "vulkan_device.hpp"

std::string compactBytes(const VkDeviceSize bytes)
{
	const char* units[] = { "B", "KB", "MB", "GB", "TB" };
	uint32_t unit = 0;
	float exact = bytes;
	while (exact > 1024)
	{
		exact /= 1024;
		unit++;
	}
	return std::to_string(exact) + " " + units[unit];
}

std::string MemoryStructure::toString() const
{
	std::string str;
	for (uint32_t i = 0; i < m_memoryProperties.memoryHeapCount; i++)
	{
		str += "Memory Heap " + std::to_string(i) + ":\n";
		str += " - Size: " + compactBytes(m_memoryProperties.memoryHeaps[i].size) + "\n";
		str += " - Flags: " + string_VkMemoryHeapFlags(m_memoryProperties.memoryHeaps[i].flags) + "\n";
		str += " - Memory Types:\n";
		for (uint32_t j = 0; j < m_memoryProperties.memoryTypeCount; j++)
		{
			if (m_memoryProperties.memoryTypes[j].heapIndex == i)
			{
				str += "    - Memory Type " + std::to_string(j) + ": " + string_VkMemoryPropertyFlags(m_memoryProperties.memoryTypes[j].propertyFlags) + "\n";
			}
		}
	}
	return str;
}

std::optional<uint32_t> MemoryStructure::getStagingMemoryType(const uint32_t typeFilter) const
{
	std::vector<uint32_t> types = getMemoryTypes(VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT | VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT, typeFilter);

	if (types.empty())
		return std::nullopt;

	return types.front();
}

std::vector<uint32_t> MemoryStructure::getMemoryTypes(const VkMemoryPropertyFlags properties, const uint32_t typeFilter) const
{
	std::vector<uint32_t> suitableTypes{};
	for (uint32_t i = 0; i < m_memoryProperties.memoryTypeCount; i++)
	{
		if ((typeFilter & (1 << i)) && doesMemoryContainProperties(i, properties)) {
            suitableTypes.push_back(i);
        }
	}
	return suitableTypes;
}

bool MemoryStructure::doesMemoryContainProperties(const uint32_t type, const VkMemoryPropertyFlags property) const
{
	return (m_memoryProperties.memoryTypes[type].propertyFlags & property) == property;
}

MemoryStructure::MemoryStructure(const VulkanGPU gpu)
{
	vkGetPhysicalDeviceMemoryProperties(gpu.m_vkHandle, &m_memoryProperties);
	std::cout << "\n*************************************************************************\n"
	          <<   "*************************** Memory Properties ***************************\n"
	          <<   "*************************************************************************\n\n"
			  << toString()
			  << "\n*************************************************************************\n"
			  <<   "*************************************************************************\n"
			  <<   "*************************************************************************\n\n";
}

VkDeviceSize MemoryChunk::getSize() const
{
	return m_size;
}

uint32_t MemoryChunk::getMemoryType() const
{
	return m_memoryType;
}

bool MemoryChunk::isEmpty() const
{
	uint32_t freeSize = 0;
	for (const auto& size : m_unallocatedData | std::views::values)
	{
		freeSize += size;
	}
	return freeSize == m_size;
}

MemoryChunk::MemoryBlock MemoryChunk::allocate(const VkDeviceSize newSize)
{
	VkDeviceSize best = m_size;
	if (newSize > m_unallocatedData[m_biggestChunk])
		return {0, 0, m_chunkID};

	for (const auto& [offset, size] : m_unallocatedData)
	{
		if (size >= newSize && (best == m_size || m_unallocatedData[best] > size))
		{
			best = offset;
		}
	}

	if (best == m_size)
		return {0, 0, m_chunkID};

	const VkDeviceSize bestSize = m_unallocatedData[best];
	m_unallocatedData.erase(best);
	if (bestSize != newSize)
		m_unallocatedData[best + newSize] = bestSize - newSize;
	
	std::cout << "Allocated block of size " << compactBytes(newSize) << " at offset " << best << " of memory type " << m_memoryType << '\n';

	if (m_biggestChunk == best)
	{
		for (const auto& [offset, size] : m_unallocatedData)
		{
			if (!m_unallocatedData.contains(m_biggestChunk) || size > m_unallocatedData[m_biggestChunk])
				m_biggestChunk = offset;
		}
	}

	m_unallocatedSize -= newSize;

	return {newSize, best, m_chunkID};
}

void MemoryChunk::deallocate(const MemoryBlock& block)
{
	if (block.chunk != m_chunkID)
		throw std::runtime_error("Block does not belong to this chunk!");

	m_unallocatedData[block.offset] = block.size;
	std::cout << "Deallocated block of size " << compactBytes(block.size) << " at offset " << block.offset << " of memory type " << m_memoryType << '\n';

	m_unallocatedSize += block.size;

	defragment();
}

VkDeviceSize MemoryChunk::getBiggestChunkSize() const
{
	return m_unallocatedData.empty() ? 0 : m_unallocatedData.at(m_biggestChunk);
}

VkDeviceSize MemoryChunk::getRemainingSize() const
{
	return m_unallocatedSize;
}

MemoryChunk::MemoryChunk(const VkDeviceSize size, const uint32_t memoryType, const VkDeviceMemory vkHandle)
	: m_chunkID(m_chunkCount++), m_size(size), m_memoryType(memoryType), m_memory(vkHandle), m_unallocatedSize(size)
{
	m_unallocatedData[0] = size;
}

void MemoryChunk::defragment()
{
	if (m_unallocatedData.size() <= 1)
	{
		std::cout << "No need to defragment memory chunk " << m_chunkID << '\n';
		return;
	}
	std::cout << "Defragmenting memory chunk " << m_chunkID << '\n';
	uint32_t mergeCount = 0;
	for (auto it = m_unallocatedData.begin(); it != m_unallocatedData.end();)
	{
		auto next = std::next(it);
		if (next == m_unallocatedData.end())
		{
			break;
		}
		if (next != m_unallocatedData.end() && it->first + it->second == next->first)
		{
			
			it->second += next->second;
			if (next->first == m_biggestChunk || it->second > m_unallocatedData[m_biggestChunk])
				m_biggestChunk = it->first;

			std::cout << "Merged blocks at offsets " << it->first << " and " << next->first << ", new size: " << compactBytes(it->second) << '\n';
			mergeCount++;

			m_unallocatedData.erase(next);

		}
		else
		{
			++it;
		}
	}
	std::cout << "Defragmented " << mergeCount << " blocks" << '\n';
}

VulkanMemoryAllocator::VulkanMemoryAllocator(const VulkanDevice& device, const VkDeviceSize defaultChunkSize)
	: m_memoryStructure(device.m_physicalDevice), m_chunkSize(defaultChunkSize), m_device(device.m_vkHandle)
{

}

void VulkanMemoryAllocator::free()
{
	for (const MemoryChunk& memoryBlock : m_memoryChunks)
	{
		vkFreeMemory(m_device, memoryBlock.m_memory, nullptr);
	}
	m_memoryChunks.clear();
}

MemoryChunk::MemoryBlock VulkanMemoryAllocator::allocate(const VkDeviceSize size, const uint32_t memoryType)
{
	for (auto& memoryChunk : m_memoryChunks)
	{
		if (memoryChunk.m_memoryType == memoryType)
		{
			const MemoryChunk::MemoryBlock block = memoryChunk.allocate(size);
			if (block.size != 0) return block;
		}
	}

	VkMemoryAllocateInfo allocInfo{};
	allocInfo.sType = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO;
	allocInfo.allocationSize = m_chunkSize;
	allocInfo.memoryTypeIndex = memoryType;

	VkDeviceMemory memory;
	if (vkAllocateMemory(m_device, &allocInfo, nullptr, &memory) != VK_SUCCESS)
	{
		throw std::runtime_error("Failed to allocate memory");
	}

	m_memoryChunks.push_back(MemoryChunk(m_chunkSize, memoryType, memory));
	std::cout << "Allocated chunk of size " << compactBytes(m_chunkSize) << " of memory type " << memoryType << " (ID: " << m_memoryChunks.back().m_chunkID << ")\n";
	return m_memoryChunks.back().allocate(size);
}

MemoryChunk::MemoryBlock VulkanMemoryAllocator::searchAndAllocate(const VkDeviceSize size, const MemoryPropertyPreferences properties, const uint32_t typeFilter, const bool includeHidden)
{
	const std::vector<uint32_t> memoryType = m_memoryStructure.getMemoryTypes(properties.desiredProperties, typeFilter);
	uint32_t bestType = 0;
	VkDeviceSize bestSize = 0;
	bool doesBestHaveUndesired = false;
	for (const auto& type : memoryType)
	{
		if (!includeHidden && m_hiddenTypes.contains(type))
			continue;

		const bool doesMemoryHaveUndesired = m_memoryStructure.doesMemoryContainProperties(type, properties.undesiredProperties);
		if (!properties.allowUndesired && doesMemoryHaveUndesired)
			continue;

		if (bestSize != 0 && !doesBestHaveUndesired && doesMemoryHaveUndesired)
			continue;

		if (suitableChunkExists(type, size))
			return allocate(size, type);

		const VkDeviceSize remainingSize = getRemainingSize(m_memoryStructure.m_memoryProperties.memoryTypes[type].heapIndex);
		if (remainingSize >= bestSize)
		{
			bestType = type;
			bestSize = remainingSize;
			doesBestHaveUndesired = doesMemoryHaveUndesired;
		}
	}
	return allocate(size, bestType);
}

void VulkanMemoryAllocator::deallocate(const MemoryChunk::MemoryBlock& block)
{
	m_memoryChunks[block.chunk].deallocate(block);
	if (m_memoryChunks[block.chunk].isEmpty())
	{
		vkFreeMemory(m_device, m_memoryChunks[block.chunk].m_memory, nullptr);
		m_memoryChunks.erase(m_memoryChunks.begin() + block.chunk);
		std::cout << "Freed empty chunk " << block.chunk << '\n';
	}
}

void VulkanMemoryAllocator::hideMemoryType(const uint32_t type)
{
	std::cout << "Hiding memory type " << type << '\n';
	m_hiddenTypes.insert(type);
}

void VulkanMemoryAllocator::unhideMemoryType(const uint32_t type)
{
	std::cout << "Unhiding memory type " << type << '\n';
	m_hiddenTypes.erase(type);
}

const MemoryStructure& VulkanMemoryAllocator::getMemoryStructure() const
{
	return m_memoryStructure;
}

VkDeviceSize VulkanMemoryAllocator::getRemainingSize(const uint32_t heap) const
{
	VkDeviceSize remainingSize = m_memoryStructure.m_memoryProperties.memoryHeaps[heap].size;
	for (const auto& chunk : m_memoryChunks)
	{
		if (m_memoryStructure.m_memoryProperties.memoryTypes[chunk.m_memoryType].heapIndex == heap)
		{
			remainingSize -= chunk.getSize();
		}
	}
	return remainingSize;
}

bool VulkanMemoryAllocator::suitableChunkExists(const uint32_t memoryType, const VkDeviceSize size) const
{
	for (const auto& chunk : m_memoryChunks)
	{
		if (chunk.m_memoryType == memoryType && chunk.getBiggestChunkSize() >= size)
		{
			return true;
		}
	}
	return false;
}

bool VulkanMemoryAllocator::isMemoryTypeHidden(const unsigned value) const
{
	return m_hiddenTypes.contains(value);
}
