
#include <iostream>
#include <stdexcept>

#include "sdl_window.hpp"
#include "vulkan_context.hpp"
#include "vulkan_device.hpp"
#include "vulkan_gpu.hpp"
#include "vulkan_queues.hpp"

VulkanGPU getCorrectGPU(const VulkanContext& context)
{
	const std::vector<VulkanGPU> gpus = context.getGPUs();
	for (const VulkanGPU& gpu : gpus)
	{
		const VkPhysicalDeviceProperties properties = gpu.getProperties();
		if (properties.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU)
		{
			return gpu;
		}
	}
	throw std::runtime_error("No discrete GPU found");
}

int main()
{
	SDLWindow window{"Test", 1920, 1080};
	VulkanContext context{VK_API_VERSION_1_3, true, window.getRequiredVulkanExtensions()};
	window.createSurface(context);

	const VulkanGPU selectedGPU = getCorrectGPU(context);
	const GPUQueueStructure queueStructure = selectedGPU.getQueueFamilies();
	const QueueFamily graphicsQueueFamily = queueStructure.findQueueFamily(VK_QUEUE_GRAPHICS_BIT);
	const QueueFamily presentQueueFamily = queueStructure.findPresentQueueFamily(window.getSurface());
	const QueueFamily transferQueueFamily = queueStructure.findQueueFamily(VK_QUEUE_TRANSFER_BIT);

	QueueFamilySelector selector{queueStructure};
	selector.selectQueueFamily(graphicsQueueFamily, QueueFamilyTypeBits::GRAPHICS);
	selector.selectQueueFamily(presentQueueFamily, QueueFamilyTypeBits::PRESENT);
	const QueueSelection graphicsQueuePos = selector.getOrAddQueue(graphicsQueueFamily, 1.0);
	const QueueSelection presentQueuePos = selector.getOrAddQueue(presentQueueFamily, 1.0);
	const QueueSelection transferQueuePos = selector.addQueue(transferQueueFamily, 1.0);

	VulkanDevice& device = context.createDevice(selectedGPU, selector, {VK_KHR_SWAPCHAIN_EXTENSION_NAME}, {});
	window.createSwapchain(device, {VK_FORMAT_B8G8R8A8_SRGB, VK_COLOR_SPACE_SRGB_NONLINEAR_KHR});

	VkCommandBuffer graphicsBuffer = device.createSingleCommandBuffer(graphicsQueueFamily, 0, false);
	VkCommandBuffer presentBuffer = device.getOrCreateSingleCommandBuffer(presentQueueFamily, 0, false);

	device.disallowMemoryType(5);
	device.configureStagingBuffer(5LL * 1024 * 1024, transferQueuePos);

	while (!window.shouldClose())
	{
		window.pollEvents();
		// Render frame
	}

	// Free resources
	window.free();
	context.free();
	return 0;
}